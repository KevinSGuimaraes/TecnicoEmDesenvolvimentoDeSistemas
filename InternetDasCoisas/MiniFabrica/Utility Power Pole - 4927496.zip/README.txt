Utility Power Pole by ToriLeighR on Thingiverse: https://www.thingiverse.com/thing:4927496

Summary:
3D rendered model of a simple utility pole. Please like and share pics of your prints if you make this! Check out my 200+ other designs!https://www.thingiverse.com/torileighr/designs