Traffic Sign Models by VipSaran on Thingiverse: https://www.thingiverse.com/thing:3010541

Summary:
A bunch of different traffic sign models intended to be labeled and then happily played with :)The models are designed to be proportionally accurate, stable on carpet, modular (to a degree) and to be easily printed (e.g. octagonal pole shape instead of round one).Provided Signs-3Dprint.svg file has the vectors used for printing the labels.Enjoy and post your make! :)