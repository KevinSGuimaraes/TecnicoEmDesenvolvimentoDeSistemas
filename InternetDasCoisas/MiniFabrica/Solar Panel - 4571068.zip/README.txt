Solar Panel by Zaphord on Thingiverse: https://www.thingiverse.com/thing:4571068

Summary:
First attempt at making terrain in Blender from scratch. Basic solar panel on a hex base for 6mm wargaming.