Realistic Solar Panel Model by abrokadabra on Thingiverse: https://www.thingiverse.com/thing:1073265

Summary:
Can be used for props, other models, renderings, etc. etc.The model is very clean and low poly, so feel free to make an array of 1000+ panels!-"Flat" and "low poly" are a solid rectangle, whereas "upright" has a very thin middle, for increased aesthetic accuracy, and prints with brim only.-The "Display Model" comes with a built-in stand and is tilted at 30 degrees. It will print with brim only.