Model Lamp Post by KnightlyDesigns on Thingiverse: https://www.thingiverse.com/thing:2712707

Summary:
Miniature Lamp post. About 14cm in height. Has a center line down the bottom portion to allow wiring to and LED in the cap.Thanks to @aprilla for a revision on the holes of the top for those who find them too small!