Box per DHT11 sensore temperatura e umidita' by iotgemini on Thingiverse: https://www.thingiverse.com/thing:4341432

Summary:
Questo e' un semplice contenitore per il sensore di Temperatura e Umidita' chiamato DHT11.Il Design di questa scatoletta e' stato offeto dalla IOTGEMINI:https://www.iotgemini.com/