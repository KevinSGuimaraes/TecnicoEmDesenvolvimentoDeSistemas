Factory by Gavin_V on Thingiverse: https://www.thingiverse.com/thing:2531516

Summary:
Factory 16x20mm footprint