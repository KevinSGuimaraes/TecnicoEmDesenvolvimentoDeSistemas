28mm Bus Stop Bench by ISOpod on Thingiverse: https://www.thingiverse.com/thing:2117487

Summary:
Even in a zombie apocalypse, it's nice to have a seat while waiting for the next bus. 