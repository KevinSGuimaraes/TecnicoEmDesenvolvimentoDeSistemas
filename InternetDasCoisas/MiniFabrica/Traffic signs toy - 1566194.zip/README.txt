Traffic signs toy by jcarolinares on Thingiverse: https://www.thingiverse.com/thing:1566194

Summary:
I remember this little game made of wood in my childhood, so I decided to create my own version. If you want you have the .scad file to create new signals models.Hope you like!WARNING: This IS NOT A TOY FOR LITTLE CHILDREN, they could SWALLOW the small pieces!