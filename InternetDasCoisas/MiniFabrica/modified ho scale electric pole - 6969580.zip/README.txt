modified ho scale electric pole by hujkghujik on Thingiverse: https://www.thingiverse.com/thing:6969580

Summary:
noticed the support bars for the crossbar were not great, so i improved it ! Hopefully not stepping on anyones toes here !