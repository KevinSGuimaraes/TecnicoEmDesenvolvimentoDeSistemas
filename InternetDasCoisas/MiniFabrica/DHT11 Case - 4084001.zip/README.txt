DHT11 Case by EEdvard on Thingiverse: https://www.thingiverse.com/thing:4084001

Summary:
Simple DHT11 case for greenhouse project. The sensor snaps in onto printed posts and cover holds it down. Cover could be glued to the case body, if needed. Also the sensor cage (blue on the pictures) could be glued to PCB to avoid sensor sticking out of the case. 2 holes for fastening are for M5 fasteners. Also double sided tape could be used, to attach the case in the greenhouse.