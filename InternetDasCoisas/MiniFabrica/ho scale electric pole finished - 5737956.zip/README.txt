ho scale electric pole finished by brian369 on Thingiverse: https://www.thingiverse.com/thing:5737956

Summary:
This object was made in Tinker Cad.ender 3 v2will need supports i used Cura tree supports.