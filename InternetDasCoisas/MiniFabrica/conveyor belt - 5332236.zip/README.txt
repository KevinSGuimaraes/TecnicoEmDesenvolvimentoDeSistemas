conveyor belt by mstfproje on Thingiverse: https://www.thingiverse.com/thing:5332236

Summary:
kullanılan malzemelerredüktörlü motor5mm metal mil 7,5cm ve 8,5cm625 rulman 4 adet10mm saplama (tij) ve 8 adet somunpvc branda