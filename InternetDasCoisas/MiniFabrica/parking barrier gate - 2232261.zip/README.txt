parking barrier gate by julioms on Thingiverse: https://www.thingiverse.com/thing:2232261

Summary:
It's a simple parking barrier gate controlled by Arduino. The barrier fits perfectly in the servomotor axis. 