Solar-Panel by karlkowalski on Thingiverse: https://www.thingiverse.com/thing:4948380

Summary:
Modell eines Solarpanels 1:100 für Flachdächer mit einer Neigung von 32°.SolarpanelGestellBetonplattenDas Panel muss auf das Gestell geklebt werden.Update:Neu Design GestellNeu Design PanelNeu Design GestellNeu Design Betonplatte (ohne Beschriftung)Model of a solar panel ratio 1:100 for flat roofs with an inclination of 32°.Solar panel Frame Concrete slabsThe panel must be glued to the frame.Update:New design frameNew design panelNew design frameNew design concrete slab (without lettering)