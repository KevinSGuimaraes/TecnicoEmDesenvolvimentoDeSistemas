Cell Tower by SkyJumper on Thingiverse: https://www.thingiverse.com/thing:4249614

Summary:
Cell Tower for Model Railroad. Easy print. Can be re-scaled.  Advise to print with a resin printer for the small detail.  I used scrap supports from the resin printer for the cables up the tower.