Traffic light for H0 Train by MV1985 on Thingiverse: https://www.thingiverse.com/thing:2062048

Summary:
Traffic light for H0 Train