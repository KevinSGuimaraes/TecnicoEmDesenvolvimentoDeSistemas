Factorio Solar Panels by warmarine759 on Thingiverse: https://www.thingiverse.com/thing:3827596

Summary:
A nice easy solar panel designI printed with 0 bottom layers to save some time 