Pi Traffic Light Case by ryanpriore on Thingiverse: https://www.thingiverse.com/thing:1465400

Summary:
This is a case for the Low Voltage Labs Pi Traffic Light: http://lowvoltagelabs.com/products/pi-traffic/