Silo for Siku 1:87 by PitpatV on Thingiverse: https://www.thingiverse.com/thing:4141874

Summary:
Silo for Siku 1:87.Roof can be removed, Silo can be filled and there is an opening on the bottom side.Roof is printed without supports.For silo support in the middle was neccessary.SiloV2 is with a gate on the lower side for closing the silo.Roof is the same for both versions.For SiloV2 a Cura file with all settings is attached.