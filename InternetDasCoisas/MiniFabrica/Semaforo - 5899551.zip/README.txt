Semaforo by lexumanum on Thingiverse: https://www.thingiverse.com/thing:5899551

Summary:
Es un simple semáforo para poner una placa Arduino 1 y baterías en la caja inferior. 