Traffic light by Arduinoklg on Thingiverse: https://www.thingiverse.com/thing:3988668

Summary:
Hi dier friends! In this video I will show you how I make a home-made traffic light.Video in inglish for Thingiverse community https://youtu.be/ypcaBGKPlikIn this video I will show you how to make a homemade traffic light on an Arduino.How to create a 3d modelHow to print a 3D model on a 3D printerHow to assemble and solder a traffic light diagramProgram code and circuit diagram http://forklg.ru/viewtopic.php?f=104&amp;t=1355&amp;p=5580#p5579