00 Gauge Bus Stop by 134B29F on Thingiverse: https://www.thingiverse.com/thing:6718821

Summary:
Bus Stop for Model Railways ectstandard bus shelter = 32mm high 36mm widehowever can be scaled to suit all gauges,