Electric pole 22kV scale H0 by Daavii on Thingiverse: https://www.thingiverse.com/thing:6588932

Summary:
Electric pole, height 100mm