Traffic light / Semáforo by pzanon on Thingiverse: https://www.thingiverse.com/thing:776642

Summary:
LEDs can be added to the traffic light  Semáforo al que se le pueden añadir LED's