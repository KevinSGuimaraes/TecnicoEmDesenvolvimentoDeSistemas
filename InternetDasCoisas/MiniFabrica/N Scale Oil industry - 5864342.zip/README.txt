N Scale Oil industry by wdevaal on Thingiverse: https://www.thingiverse.com/thing:5864342

Summary:
This is a series of parts that allow for a custom oil industry on your N Scale layout.Remix from: https://www.thingiverse.com/thing:4199954