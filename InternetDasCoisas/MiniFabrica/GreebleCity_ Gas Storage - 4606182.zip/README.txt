GreebleCity: Gas Storage by Fisk400 on Thingiverse: https://www.thingiverse.com/thing:4606182

Summary:
So much gas...If you like these models and want them to continue, please consider supporting me on Patreon. If you join you will get instant access to the whole months worth of models and you will get some exclusive models (Read the tiers carefully.).Links:https://www.patreon.com/GreebleCityhttps://www.reddit.com/r/GreebleCity/Collection:https://www.thingiverse.com/fisk400/collections/greeblecity