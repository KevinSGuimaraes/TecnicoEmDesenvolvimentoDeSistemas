Cell Tower by eric-barnett11 on Thingiverse: https://www.thingiverse.com/thing:3492982

Summary:
Just thought I could make this, enjoy.