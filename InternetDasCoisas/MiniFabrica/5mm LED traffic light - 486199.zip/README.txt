 5mm LED  traffic light by liteul on Thingiverse: https://www.thingiverse.com/thing:486199

Summary:
Designed for an Arduino workshop.5 mm leds, wires, and code!made with sketchup  2014.  