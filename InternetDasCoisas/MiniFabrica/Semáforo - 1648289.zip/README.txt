Semáforo by tecnoloxia_org on Thingiverse: https://www.thingiverse.com/thing:1648289

Summary:
Semáforo para maqueta programada con arduino.As pezas axustan mediante presión, sen necesidade de pegar nada.http://tecnoloxia.orgPodedes modificalo copiando este archivo de OnShape:https://cad.onshape.com/documents/cadd2ea449e4c210e79850ae/w/55250abf582af8d08d3a0e72/e/65c8596635b1470e8f99ca04