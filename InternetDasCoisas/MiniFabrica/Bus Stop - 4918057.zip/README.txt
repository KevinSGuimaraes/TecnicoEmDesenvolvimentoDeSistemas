Bus Stop by ChrisTepes on Thingiverse: https://www.thingiverse.com/thing:4918057

Summary:
A 28/32mm scaled bus stop for modern and cyberpunk war games designed with Tinkercad. It was inspired by a design by Jean-Phillipe Savoie. I designed the model to be printed on it's back - no supports are needed if printed in this orientation. The destination/time sign is 4x40mm and the ad sign is 20x28mm.