Lamp post BMG scenary by Halec01 on Thingiverse: https://www.thingiverse.com/thing:3439881

Summary:
Lamp post for BMG game