Gaslands Highway Gate by Syllogy on Thingiverse: https://www.thingiverse.com/thing:2969916

Summary:
A gate for use in Gaslands, or for any other tabletop game where post-apocalyptic highway signs might be needed.