Bus Stop Madrid by Carba on Thingiverse: https://www.thingiverse.com/thing:786367

Summary:
Divided in 6 printable parts;  roof (x1)  seat (x1)  central column (x3)  corner column (x2)  final column (x2)  glass (x6 optional)