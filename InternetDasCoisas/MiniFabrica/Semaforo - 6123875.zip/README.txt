Semaforo by Alamanera on Thingiverse: https://www.thingiverse.com/thing:6123875

Summary:
SEMAFORO PARA LED DE 5MM 