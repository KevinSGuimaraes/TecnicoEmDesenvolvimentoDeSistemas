Ultrasonic Sensor Housing - HC-SR04  by dstark125 on Thingiverse: https://www.thingiverse.com/thing:1708627

Summary:
Small housing I made that just snaps together to hold the sensor.  I'm going to mount using a few small nails through the back.  Edges don't fit together perfectly, but for my application (only seeing it from 4+ feet away) it looks great.