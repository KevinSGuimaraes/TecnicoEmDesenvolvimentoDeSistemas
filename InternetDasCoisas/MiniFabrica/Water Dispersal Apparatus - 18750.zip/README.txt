Water Dispersal Apparatus by BrianStamile on Thingiverse: https://www.thingiverse.com/thing:18750

Summary:
Now you can cancel that trip you had planned to NYC to see its world famous fire hydrants!  Print out and enjoy this 123D Catch scan of a real live NYC Hydrant today, and save on airfare!