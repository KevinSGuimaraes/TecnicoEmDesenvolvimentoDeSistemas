Factory and Conveyor Belt - 28/32mm by Aarcana on Thingiverse: https://www.thingiverse.com/thing:3186888

Summary:
This is a nuka cola factory and conveyor belt pieces that goes with itdesigned for Fallout Wasteland Warfare sceneryI can't find one of the buildings I used to credit the remix (it's called "power_supply_junction.stl" and has a warhammer imperial logo on it)