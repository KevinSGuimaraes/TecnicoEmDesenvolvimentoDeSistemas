Pumpjack by HarlanDMii on Thingiverse: https://www.thingiverse.com/thing:17025

Summary:
Im from West Texas. What else is there?I guess my eyes were bigger than my build platform.. I created this for the Replicator then realized it was way too big. It will fit at 1/2 scale though.This set has been scaled to fit on the build platform of the Thing-O-Matic (It's 1/4 scale of the original)This object was created in OpenScad (inkscape to make some of the shapes). I drew it by looking at pictures, so the scale is probably not all that accurate. https://youtu.be/SRW2wSRrGdE