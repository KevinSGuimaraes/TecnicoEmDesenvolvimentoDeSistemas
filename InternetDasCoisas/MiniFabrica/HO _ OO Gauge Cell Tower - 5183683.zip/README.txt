HO / OO Gauge Cell Tower by Danvl1991 on Thingiverse: https://www.thingiverse.com/thing:5183683

Summary:
50ft Cell tower with various accessories for the top