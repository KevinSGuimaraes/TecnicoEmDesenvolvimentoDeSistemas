Factory by lorennorman on Thingiverse: https://www.thingiverse.com/thing:29280

Summary:
A factory. No, not a FactoryFactory.It makes things. What kinds of things? I dunno, mans? Extra mans? Units? Shields?(...or, wait. Isn't it Hammers now?)25x25mm base, fits in my hex unit grid design.Go hammer yourself: https://tinkercad.com/things/cZHV7xDzF5f-factory