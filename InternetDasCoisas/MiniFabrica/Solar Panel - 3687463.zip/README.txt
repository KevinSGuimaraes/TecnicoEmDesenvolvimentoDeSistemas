Solar Panel by sfransky on Thingiverse: https://www.thingiverse.com/thing:3687463

Summary:
Solar panel