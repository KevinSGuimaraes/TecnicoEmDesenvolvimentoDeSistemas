Traffic Signs Game by AngF on Thingiverse: https://www.thingiverse.com/thing:1307920

Summary:
These are the pieces of game to learn the traffic signs used in Switzerland. They are rather similar to those used in other parts of the world; however, the conventions may differ.It is thought as a game for 12 year old students. The board has not yet been created but an initial test with a "draft" was successful.All the pieces (except for the cars) are lego-compatible.