BTS tower by Bhavesh_g on Thingiverse: https://www.thingiverse.com/thing:5533539

Summary:
BTS tower or cell tower 