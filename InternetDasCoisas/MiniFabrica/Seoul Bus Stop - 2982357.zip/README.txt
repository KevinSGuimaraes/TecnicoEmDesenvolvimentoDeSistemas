Seoul Bus Stop by AndroG on Thingiverse: https://www.thingiverse.com/thing:2982357

Summary:
Seoul Bus Stop