Old Victorian Boiler by robertmccornet on Thingiverse: https://www.thingiverse.com/thing:5961836

Summary:
This object was made in Tinkercad. Edit it online https://www.tinkercad.com/things/7OoQJVNiLWm